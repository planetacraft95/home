import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const serverRequests = pgTable("server_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  discord: text("discord"),
  serverName: text("server_name").notNull(),
  version: text("version").notNull(),
  gamemodes: text("gamemodes").array().notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertServerRequestSchema = createInsertSchema(serverRequests).omit({
  id: true,
  createdAt: true,
}).extend({
  discord: z.string().optional(),
  description: z.string().optional(),
  gamemodes: z.array(z.enum(["survival", "creative", "parkour", "skyblock", "bedwars", "custom"])).min(1, "Select at least one gamemode"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertServerRequest = z.infer<typeof insertServerRequestSchema>;
export type ServerRequest = typeof serverRequests.$inferSelect;
