import sgMail from '@sendgrid/mail';

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || process.env.SENDGRID_API_KEY_ENV_VAR || "";
const FROM_EMAIL = process.env.FROM_EMAIL || "noreply@studiosnova.com";

if (SENDGRID_API_KEY) {
  sgMail.setApiKey(SENDGRID_API_KEY);
}

interface ServerRequestEmailData {
  name: string;
  email: string;
  discord?: string;
  serverName: string;
  version: string;
  gamemodes: string[];
  description?: string;
}

export async function sendServerRequestEmail(data: ServerRequestEmailData): Promise<boolean> {
  if (!SENDGRID_API_KEY) {
    console.warn('SendGrid API key not provided, simulating email send');
    console.log('Server request email data:', data);
    return true;
  }

  try {
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a2e; color: #ffffff; padding: 20px; border-radius: 10px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #22c55e; margin: 0;">🎮 Nueva Solicitud de Servidor - Studios Nova</h1>
        </div>
        
        <div style="background: #16213e; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <h2 style="color: #22c55e; margin-top: 0;">📋 Información del Cliente</h2>
          <p><strong>Nombre:</strong> ${data.name}</p>
          <p><strong>Email:</strong> ${data.email}</p>
          ${data.discord ? `<p><strong>Discord:</strong> ${data.discord}</p>` : ''}
        </div>
        
        <div style="background: #16213e; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <h2 style="color: #3b82f6; margin-top: 0;">⚙️ Configuración del Servidor</h2>
          <p><strong>Nombre del Servidor:</strong> ${data.serverName}</p>
          <p><strong>Versión de Minecraft:</strong> ${data.version}</p>
          <p><strong>Modalidades:</strong> ${data.gamemodes.join(', ')}</p>
          ${data.description ? `<p><strong>Descripción:</strong><br>${data.description}</p>` : ''}
        </div>
        
        <div style="background: #065f46; padding: 15px; border-radius: 8px; border-left: 4px solid #22c55e;">
          <p style="margin: 0; font-size: 14px;">
            <strong>⏰ Recordatorio:</strong> Contactar al cliente en las próximas 24 horas para confirmar los detalles y comenzar la configuración del servidor.
          </p>
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #374151;">
          <p style="color: #9ca3af; font-size: 12px;">
            Studios Nova - Creadores Profesionales de Servidores de Minecraft
          </p>
        </div>
      </div>
    `;

    const textContent = `
Nueva Solicitud de Servidor - Studios Nova

INFORMACIÓN DEL CLIENTE:
- Nombre: ${data.name}
- Email: ${data.email}
${data.discord ? `- Discord: ${data.discord}` : ''}

CONFIGURACIÓN DEL SERVIDOR:
- Nombre del Servidor: ${data.serverName}
- Versión de Minecraft: ${data.version}
- Modalidades: ${data.gamemodes.join(', ')}
${data.description ? `- Descripción: ${data.description}` : ''}

Recordatorio: Contactar al cliente en las próximas 24 horas.
    `;

    const msg = {
      to: 'ayudazonepvp@gmail.com',
      from: FROM_EMAIL,
      subject: `🎮 Nueva Solicitud de Servidor: ${data.serverName} (${data.gamemodes.join(', ')})`,
      text: textContent,
      html: htmlContent,
    };

    await sgMail.send(msg);
    return true;
  } catch (error) {
    console.error('Error sending server request email:', error);
    return false;
  }
}
