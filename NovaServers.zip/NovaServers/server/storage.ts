import { type User, type InsertUser, type ServerRequest, type InsertServerRequest } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createServerRequest(request: InsertServerRequest): Promise<ServerRequest>;
  getServerRequests(): Promise<ServerRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private serverRequests: Map<string, ServerRequest>;

  constructor() {
    this.users = new Map();
    this.serverRequests = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createServerRequest(insertRequest: InsertServerRequest): Promise<ServerRequest> {
    const id = randomUUID();
    const request: ServerRequest = { 
      ...insertRequest, 
      id,
      createdAt: new Date(),
      discord: insertRequest.discord || null,
      description: insertRequest.description || null
    };
    this.serverRequests.set(id, request);
    return request;
  }

  async getServerRequests(): Promise<ServerRequest[]> {
    return Array.from(this.serverRequests.values());
  }
}

export const storage = new MemStorage();
