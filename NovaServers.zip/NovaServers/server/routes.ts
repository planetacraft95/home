import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertServerRequestSchema } from "@shared/schema";
import { sendServerRequestEmail } from "./services/email";

export async function registerRoutes(app: Express): Promise<Server> {
  
  app.post("/api/server-request", async (req, res) => {
    try {
      const validatedData = insertServerRequestSchema.parse(req.body);
      
      // Save to storage
      const serverRequest = await storage.createServerRequest(validatedData);
      
      // Send email
      const emailSent = await sendServerRequestEmail(validatedData);
      
      if (!emailSent) {
        console.warn('Email failed to send, but request was saved');
      }
      
      res.json({ 
        success: true, 
        message: "Solicitud enviada correctamente",
        id: serverRequest.id
      });
    } catch (error) {
      console.error('Server request error:', error);
      res.status(400).json({ 
        success: false, 
        message: "Error al procesar la solicitud" 
      });
    }
  });

  app.get("/api/server-requests", async (req, res) => {
    try {
      const requests = await storage.getServerRequests();
      res.json(requests);
    } catch (error) {
      console.error('Get server requests error:', error);
      res.status(500).json({ 
        success: false, 
        message: "Error al obtener las solicitudes" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
