import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ServerRequestModal } from "../components/server-request-modal";
import { 
  Server, 
  Box, 
  Shield, 
  Users, 
  CheckCircle, 
  Star, 
  Infinity, 
  Timer, 
  Trophy, 
  Bed,
  Plus,
  Lightbulb,
  Rocket,
  InfoIcon,
  Hammer,
  Palette,
  TrainTrack,
  Cloud,
  Settings,
  Zap,
  HeartHandshake
} from "lucide-react";

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="bg-card/80 backdrop-blur-md border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Box className="text-primary-foreground text-xl" />
              </div>
              <span className="text-2xl font-bold text-primary glitch-effect" data-testid="brand-title">Studios Nova</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <button onClick={() => scrollToSection('inicio')} className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-inicio">
                Inicio
              </button>
              <button onClick={() => scrollToSection('servicios')} className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-servicios">
                Servicios
              </button>
              <button onClick={() => scrollToSection('modalidades')} className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-modalidades">
                Modalidades
              </button>
              <button onClick={() => scrollToSection('contacto')} className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-contacto">
                Contacto
              </button>
              <Link href="/admin" className="text-muted-foreground hover:text-primary transition-colors" data-testid="nav-admin">
                <button>Admin</button>
              </Link>
            </div>
            <Button 
              onClick={() => setIsModalOpen(true)} 
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105"
              data-testid="button-open-modal-nav"
            >
              <Server className="mr-2 h-4 w-4" />
              Pedir Servidor
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="inicio" className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 minecraft-pattern opacity-5"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent" data-testid="text-hero-title">
              Studios Nova
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8" data-testid="text-hero-subtitle">
              Creadores Profesionales de Servidores de Minecraft
            </p>
            <p className="text-lg text-muted-foreground mb-12 leading-relaxed" data-testid="text-hero-description">
              Especializados en la creación de servidores de Minecraft desde la versión 1.8 hasta 1.21. 
              Ofrecemos experiencias únicas con las mejores modalidades de juego.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => setIsModalOpen(true)} 
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
                data-testid="button-open-modal-hero"
              >
                <Rocket className="mr-3 h-5 w-5" />
                Crear Mi Servidor
              </Button>
              <Button 
                onClick={() => scrollToSection('servicios')} 
                variant="outline" 
                className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200"
                data-testid="button-learn-more"
              >
                <InfoIcon className="mr-3 h-5 w-5" />
                Conocer Más
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute top-20 right-10 floating">
          <Box className="text-primary text-6xl opacity-20" />
        </div>
        <div className="absolute bottom-20 left-10 floating" style={{animationDelay: '-1s'}}>
          <Server className="text-accent text-4xl opacity-20" />
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-20 bg-card">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-primary" data-testid="text-services-title">Nuestros Servicios</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-services-description">
              Desde servidores básicos hasta configuraciones avanzadas, creamos la experiencia perfecta para tu comunidad.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-background border border-border rounded-xl p-8 text-center hover:border-primary transition-colors" data-testid="card-service-configuration">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-primary/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                  <Settings className="text-primary text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4" data-testid="text-service-configuration-title">Configuración Profesional</h3>
                <p className="text-muted-foreground" data-testid="text-service-configuration-desc">Servidores optimizados con las mejores prácticas de rendimiento y seguridad.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-background border border-border rounded-xl p-8 text-center hover:border-primary transition-colors" data-testid="card-service-protection">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                  <Shield className="text-secondary text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4" data-testid="text-service-protection-title">Protección Anti-Griefing</h3>
                <p className="text-muted-foreground" data-testid="text-service-protection-desc">Sistemas avanzados de protección para mantener tu mundo seguro.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-background border border-border rounded-xl p-8 text-center hover:border-primary transition-colors" data-testid="card-service-support">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-accent/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                  <HeartHandshake className="text-accent text-2xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4" data-testid="text-service-support-title">Soporte 24/7</h3>
                <p className="text-muted-foreground" data-testid="text-service-support-desc">Asistencia técnica completa para mantener tu servidor funcionando.</p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center space-x-4 bg-muted rounded-xl p-6" data-testid="badge-compatibility">
              <CheckCircle className="text-primary text-2xl" />
              <span className="text-lg font-semibold" data-testid="text-compatibility">Compatible con versiones 1.8 - 1.21</span>
            </div>
          </div>
        </div>
      </section>

      {/* Game Modes Section */}
      <section id="modalidades" className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-primary" data-testid="text-modes-title">Modalidades Disponibles</h2>
            <p className="text-xl text-muted-foreground" data-testid="text-modes-description">Elige entre nuestras modalidades más populares para tu servidor</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Survival Card */}
            <Card className="game-card bg-card border border-border rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-survival">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <Hammer className="text-primary text-2xl opacity-20" />
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200" 
                  alt="Survival landscape" 
                  className="w-full h-32 object-cover rounded-lg mb-6 pixelated" 
                  data-testid="img-survival"
                />
                <h3 className="text-2xl font-bold mb-4 text-primary" data-testid="text-gamemode-survival-title">Survival</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-survival-desc">Experiencia clásica de supervivencia con recursos limitados y desafíos constantes.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Star className="text-secondary mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-survival-badge">Modalidad más popular</span>
                </div>
              </CardContent>
            </Card>
            
            {/* Creative Card */}
            <Card className="game-card bg-card border border-border rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-creative">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <Palette className="text-accent text-2xl opacity-20" />
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200" 
                  alt="Creative artwork" 
                  className="w-full h-32 object-cover rounded-lg mb-6 pixelated" 
                  data-testid="img-creative"
                />
                <h3 className="text-2xl font-bold mb-4 text-accent" data-testid="text-gamemode-creative-title">Creativo</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-creative-desc">Modo creativo con recursos ilimitados para construir tus proyectos más ambiciosos.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Infinity className="text-accent mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-creative-badge">Recursos ilimitados</span>
                </div>
              </CardContent>
            </Card>
            
            {/* Parkour Card */}
            <Card className="game-card bg-card border border-border rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-parkour">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <TrainTrack className="text-secondary text-2xl opacity-20" />
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200" 
                  alt="Parkour obstacles" 
                  className="w-full h-32 object-cover rounded-lg mb-6 pixelated" 
                  data-testid="img-parkour"
                />
                <h3 className="text-2xl font-bold mb-4 text-secondary" data-testid="text-gamemode-parkour-title">Parkour</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-parkour-desc">Desafiantes mapas de parkour con diferentes niveles de dificultad y cronómetros.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Timer className="text-secondary mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-parkour-badge">Tiempo récord</span>
                </div>
              </CardContent>
            </Card>
            
            {/* Skyblock Card */}
            <Card className="game-card bg-card border border-border rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-skyblock">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <Cloud className="text-accent text-2xl opacity-20" />
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200" 
                  alt="Floating island" 
                  className="w-full h-32 object-cover rounded-lg mb-6 pixelated" 
                  data-testid="img-skyblock"
                />
                <h3 className="text-2xl font-bold mb-4 text-accent" data-testid="text-gamemode-skyblock-title">Skyblock</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-skyblock-desc">Supervivencia en una isla flotante con recursos mínimos y máximo desafío.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Trophy className="text-accent mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-skyblock-badge">Máximo desafío</span>
                </div>
              </CardContent>
            </Card>
            
            {/* BedWars Card */}
            <Card className="game-card bg-card border border-border rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-bedwars">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <Bed className="text-destructive text-2xl opacity-20" />
                </div>
                <div className="w-full h-32 bg-gradient-to-r from-destructive/30 to-destructive/10 rounded-lg mb-6 flex items-center justify-center">
                  <Zap className="text-destructive text-4xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-destructive" data-testid="text-gamemode-bedwars-title">BedWars</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-bedwars-desc">Batalla épica por equipos para proteger tu cama y destruir las del enemigo.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Users className="text-destructive mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-bedwars-badge">Multijugador competitivo</span>
                </div>
              </CardContent>
            </Card>
            
            {/* Custom Mode Card */}
            <Card className="game-card bg-gradient-to-br from-primary/20 to-accent/20 border border-primary rounded-xl p-8 relative overflow-hidden" data-testid="card-gamemode-custom">
              <CardContent className="p-0">
                <div className="absolute top-4 right-4">
                  <Lightbulb className="text-primary text-2xl opacity-40" />
                </div>
                <div className="w-full h-32 bg-gradient-to-r from-primary/30 to-accent/30 rounded-lg mb-6 flex items-center justify-center">
                  <Plus className="text-primary text-4xl" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-primary" data-testid="text-gamemode-custom-title">¿Otra Modalidad?</h3>
                <p className="text-muted-foreground mb-4" data-testid="text-gamemode-custom-desc">¿Tienes una idea específica? Podemos crear modalidades personalizadas para ti.</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Lightbulb className="text-primary mr-2 h-4 w-4" />
                  <span data-testid="text-gamemode-custom-badge">Personalización total</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Server Info Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-primary" data-testid="text-server-info-title">Información del Servidor</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-server-info-description">
              Conecta y disfruta de nuestros servidores ya configurados con las mejores modalidades.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card className="bg-background border border-border rounded-xl p-8 mb-8" data-testid="card-server-info">
              <CardContent className="p-0">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                        <Server className="text-primary text-xl" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-primary" data-testid="text-server-address-title">Dirección del Servidor</h3>
                        <p className="text-3xl font-mono font-bold text-foreground" data-testid="text-server-address">novalith.funserver.top</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                        <Box className="text-secondary text-xl" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold" data-testid="text-versions-title">Versiones Compatibles</h3>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="outline" className="text-sm" data-testid="badge-version-1.18">1.18</Badge>
                          <Badge variant="outline" className="text-sm" data-testid="badge-version-1.19">1.19</Badge>
                          <Badge variant="outline" className="text-sm" data-testid="badge-version-1.20">1.20</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center">
                        <Users className="text-accent text-xl" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold" data-testid="text-status-title">Estado del Servidor</h3>
                        <div className="flex items-center space-x-2 mt-2">
                          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" data-testid="status-indicator"></div>
                          <span className="text-green-500 font-semibold" data-testid="text-status">En Línea</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground mb-2" data-testid="text-connect-help">Para conectarte:</p>
                      <ol className="text-sm space-y-1">
                        <li data-testid="text-connect-step-1">1. Abre Minecraft</li>
                        <li data-testid="text-connect-step-2">2. Ve a Multijugador</li>
                        <li data-testid="text-connect-step-3">3. Agregar servidor</li>
                        <li data-testid="text-connect-step-4">4. Usa: novalith.funserver.top</li>
                      </ol>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 via-accent/10 to-secondary/10">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-cta-title">¿Listo para Crear tu Servidor?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-cta-description">
            Únete a cientos de jugadores que ya confían en Studios Nova para sus servidores de Minecraft.
          </p>
          <Button 
            onClick={() => setIsModalOpen(true)} 
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-12 py-4 rounded-xl font-bold text-xl transition-all duration-200 transform hover:scale-105 shadow-2xl"
            data-testid="button-open-modal-cta"
          >
            <Rocket className="mr-3 h-6 w-6" />
            Empezar Ahora
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer id="contacto" className="bg-card border-t border-border py-12">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                <Box className="text-primary-foreground text-2xl" />
              </div>
              <span className="text-3xl font-bold text-primary" data-testid="text-footer-brand">Studios Nova</span>
            </div>
            <p className="text-muted-foreground mb-6" data-testid="text-footer-tagline">Creadores profesionales de servidores de Minecraft</p>
            <div className="border-t border-border pt-8">
              <p className="text-muted-foreground" data-testid="text-footer-copyright">© 2024 Studios Nova. Todos los derechos reservados.</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Modal */}
      <ServerRequestModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
}
