import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { 
  ArrowLeft,
  Server, 
  Mail, 
  User,
  Calendar,
  Search,
  Filter,
  Users,
  Clock,
  Lock,
  Eye,
  EyeOff
} from "lucide-react";
import type { ServerRequest } from "@shared/schema";

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordAttempt, setPasswordAttempt] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterGamemode, setFilterGamemode] = useState("");
  
  const { data: requests = [], isLoading } = useQuery<ServerRequest[]>({
    queryKey: ["/api/server-requests"],
    enabled: isAuthenticated,
  });

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple password check - in production, this should be more secure
    if (passwordAttempt === "studiosnova2024") {
      setIsAuthenticated(true);
      setPasswordAttempt("");
    } else {
      alert("Contraseña incorrecta");
      setPasswordAttempt("");
    }
  };

  // Show password prompt if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md mx-4" data-testid="card-admin-login">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="text-primary text-2xl" />
            </div>
            <CardTitle className="text-2xl font-bold text-primary" data-testid="text-login-title">
              Panel de Administración
            </CardTitle>
            <p className="text-muted-foreground" data-testid="text-login-subtitle">
              Acceso restringido - Ingresa la contraseña
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-4" data-testid="form-admin-login">
              <div>
                <Label htmlFor="password" className="text-sm font-medium">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={passwordAttempt}
                  onChange={(e) => setPasswordAttempt(e.target.value)}
                  placeholder="Ingresa la contraseña"
                  className="w-full"
                  required
                  data-testid="input-admin-password"
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90"
                data-testid="button-admin-login"
              >
                <Lock className="mr-2 h-4 w-4" />
                Acceder
              </Button>
            </form>
            <div className="mt-4 pt-4 border-t border-border text-center">
              <Link href="/" className="text-sm text-muted-foreground hover:text-primary" data-testid="link-back-home-login">
                ← Volver al inicio
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredRequests = requests.filter(request => {
    const matchesSearch = !searchTerm || 
      request.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.serverName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGamemode = !filterGamemode || (request.gamemodes && request.gamemodes.includes(filterGamemode));
    
    return matchesSearch && matchesGamemode;
  });

  const getGamemodeBadgeColor = (gamemode: string) => {
    const colors = {
      survival: "bg-green-500",
      creative: "bg-blue-500", 
      parkour: "bg-yellow-500",
      skyblock: "bg-cyan-500",
      bedwars: "bg-red-500",
      custom: "bg-purple-500"
    };
    return colors[gamemode as keyof typeof colors] || "bg-gray-500";
  };
  
  const renderGamemodeBadges = (gamemodes: string[] | undefined) => {
    if (!gamemodes || gamemodes.length === 0) return <span className="text-muted-foreground text-sm">No gamemodes</span>;
    
    return (
      <div className="flex flex-wrap gap-1">
        {gamemodes.map((gamemode) => (
          <Badge 
            key={gamemode}
            className={`${getGamemodeBadgeColor(gamemode)} text-white text-xs`}
          >
            {gamemode}
          </Badge>
        ))}
      </div>
    );
  };

  const formatDate = (date: string | Date | null) => {
    if (!date) return "N/A";
    const dateObj = date instanceof Date ? date : new Date(date);
    return dateObj.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "short", 
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="link-back-home">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Volver al Inicio
                </Button>
              </Link>
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Server className="text-primary-foreground text-lg" />
              </div>
              <h1 className="text-2xl font-bold text-primary" data-testid="text-admin-title">
                Panel de Administración
              </h1>
            </div>
            <Badge variant="outline" className="text-lg px-4 py-2" data-testid="badge-total-requests">
              {requests.length} Solicitudes
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nombre, email o servidor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-requests"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="text-muted-foreground h-4 w-4" />
              <select
                value={filterGamemode}
                onChange={(e) => setFilterGamemode(e.target.value)}
                className="bg-background border border-border rounded-md px-3 py-2 text-sm"
                data-testid="select-filter-gamemode"
              >
                <option value="">Todas las modalidades</option>
                <option value="survival">Survival</option>
                <option value="creative">Creativo</option>
                <option value="parkour">Parkour</option>
                <option value="skyblock">Skyblock</option>
                <option value="bedwars">BedWars</option>
                <option value="custom">Personalizada</option>
              </select>
            </div>
          </div>

          {(searchTerm || filterGamemode) && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">
                Mostrando {filteredRequests.length} de {requests.length} solicitudes
              </span>
              {(searchTerm || filterGamemode) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSearchTerm("");
                    setFilterGamemode("");
                  }}
                  data-testid="button-clear-filters"
                >
                  Limpiar filtros
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Cargando solicitudes...</p>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && filteredRequests.length === 0 && (
          <div className="text-center py-12">
            <Server className="h-24 w-24 text-muted-foreground mx-auto mb-6 opacity-50" />
            <h3 className="text-xl font-semibold mb-2" data-testid="text-no-requests">
              {requests.length === 0 ? "No hay solicitudes aún" : "No se encontraron solicitudes"}
            </h3>
            <p className="text-muted-foreground mb-6">
              {requests.length === 0 
                ? "Las nuevas solicitudes de servidor aparecerán aquí." 
                : "Intenta ajustar tus filtros de búsqueda."}
            </p>
          </div>
        )}

        {/* Requests Grid */}
        {!isLoading && filteredRequests.length > 0 && (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredRequests.map((request) => (
              <Card key={request.id} className="bg-card border border-border hover:border-primary transition-colors" data-testid={`card-request-${request.id}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg text-foreground" data-testid={`text-server-name-${request.id}`}>
                      {request.serverName}
                    </CardTitle>
                    <div data-testid={`badges-gamemodes-${request.id}`}>
                      {renderGamemodeBadges(request.gamemodes)}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground" data-testid={`text-version-${request.id}`}>
                    Minecraft {request.version}
                  </p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm" data-testid={`text-client-name-${request.id}`}>{request.name}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <a 
                      href={`mailto:${request.email}`}
                      className="text-sm text-primary hover:underline"
                      data-testid={`link-email-${request.id}`}
                    >
                      {request.email}
                    </a>
                  </div>

                  {request.discord && (
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-accent" data-testid={`text-discord-${request.id}`}>
                        {request.discord}
                      </span>
                    </div>
                  )}

                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground" data-testid={`text-date-${request.id}`}>
                      {formatDate(request.createdAt)}
                    </span>
                  </div>

                  {request.description && (
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <p className="text-sm" data-testid={`text-description-${request.id}`}>
                        {request.description}
                      </p>
                    </div>
                  )}

                  <div className="mt-4 pt-3 border-t border-border">
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => {
                        const subject = encodeURIComponent(`Re: Solicitud servidor ${request.serverName}`);
                        const gamemodesText = request.gamemodes?.join(', ') || 'modalidades seleccionadas';
                        const body = encodeURIComponent(
                          `Hola ${request.name},\n\nGracias por solicitar un servidor con las siguientes modalidades: ${gamemodesText} en Minecraft ${request.version}.\n\nMe pondré en contacto contigo pronto con más detalles sobre la configuración de tu servidor.\n\nSaludos,\nStudios Nova`
                        );
                        window.open(`mailto:${request.email}?subject=${subject}&body=${body}`);
                      }}
                      data-testid={`button-contact-${request.id}`}
                    >
                      <Mail className="mr-2 h-4 w-4" />
                      Contactar Cliente
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}