import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { X, RefreshCw, Send } from "lucide-react";

// Import Minecraft images
import survivalImage from '@assets/stock_images/minecraft_survival_m_23d5e7c5.jpg';
import creativeImage from '@assets/stock_images/minecraft_creative_m_5f417b2f.jpg';
import parkourImage from '@assets/stock_images/minecraft_parkour_ju_996ad8d3.jpg';
import skyblockImage from '@assets/stock_images/minecraft_skyblock_f_0a686af6.jpg';
import bedwarsImage from '@assets/stock_images/minecraft_bedwars_be_560e83a7.jpg';
import customImage from '@assets/stock_images/minecraft_custom_ser_5c39a8d2.jpg';
import type { InsertServerRequest } from "@shared/schema";

interface ServerRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CaptchaState {
  question: string;
  answer: number;
}

export function ServerRequestModal({ isOpen, onClose }: ServerRequestModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState<InsertServerRequest>({
    name: "",
    email: "",
    discord: "",
    serverName: "",
    version: "",
    gamemodes: [],
    description: "",
  });
  const [captcha, setCaptcha] = useState<CaptchaState>({ question: "", answer: 0 });
  const [captchaInput, setCaptchaInput] = useState("");

  const generateCaptcha = () => {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const operators = ['+', '-', '*'];
    const operator = operators[Math.floor(Math.random() * operators.length)];
    
    let question: string;
    let answer: number;
    
    switch(operator) {
      case '+':
        question = `${num1} + ${num2} = `;
        answer = num1 + num2;
        break;
      case '-':
        const larger = Math.max(num1, num2);
        const smaller = Math.min(num1, num2);
        question = `${larger} - ${smaller} = `;
        answer = larger - smaller;
        break;
      case '*':
        const smallNum1 = Math.floor(Math.random() * 5) + 1;
        const smallNum2 = Math.floor(Math.random() * 5) + 1;
        question = `${smallNum1} × ${smallNum2} = `;
        answer = smallNum1 * smallNum2;
        break;
      default:
        question = `${num1} + ${num2} = `;
        answer = num1 + num2;
    }
    
    setCaptcha({ question, answer });
    setCaptchaInput("");
  };

  useEffect(() => {
    if (isOpen) {
      generateCaptcha();
    }
  }, [isOpen]);

  const serverRequestMutation = useMutation({
    mutationFn: async (data: InsertServerRequest) => {
      const response = await apiRequest("POST", "/api/server-request", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "¡Solicitud enviada!",
        description: "Te contactaremos en las próximas 24 horas con los detalles de tu servidor.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/server-requests"] });
      onClose();
      setFormData({
        name: "",
        email: "",
        discord: "",
        serverName: "",
        version: "",
        gamemodes: [],
        description: "",
      });
      setCaptchaInput("");
    },
    onError: (error) => {
      toast({
        title: "Error al enviar solicitud",
        description: "Por favor, inténtalo de nuevo más tarde.",
        variant: "destructive",
      });
      console.error('Server request error:', error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const captchaAnswer = parseInt(captchaInput);
    if (captchaAnswer !== captcha.answer) {
      toast({
        title: "Respuesta incorrecta",
        description: "Por favor, resuelve la operación matemática correctamente.",
        variant: "destructive",
      });
      generateCaptcha();
      return;
    }

    if (!formData.name || !formData.email || !formData.serverName || !formData.version || !formData.gamemodes || formData.gamemodes.length === 0) {
      toast({
        title: "Campos requeridos",
        description: "Por favor, completa todos los campos obligatorios y selecciona al menos una modalidad de juego.",
        variant: "destructive",
      });
      return;
    }

    serverRequestMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof InsertServerRequest, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGamemodeToggle = (gamemode: 'survival' | 'creative' | 'parkour' | 'skyblock' | 'bedwars' | 'custom') => {
    setFormData(prev => ({
      ...prev,
      gamemodes: prev.gamemodes.includes(gamemode)
        ? prev.gamemodes.filter(g => g !== gamemode)
        : [...prev.gamemodes, gamemode]
    }));
  };

  const gamemodeOptions = [
    { value: 'survival' as const, label: 'Survival', image: survivalImage },
    { value: 'creative' as const, label: 'Creativo', image: creativeImage },
    { value: 'parkour' as const, label: 'Parkour', image: parkourImage },
    { value: 'skyblock' as const, label: 'Skyblock', image: skyblockImage },
    { value: 'bedwars' as const, label: 'BedWars', image: bedwarsImage },
    { value: 'custom' as const, label: 'Personalizada', image: customImage },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="form-container w-full max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="modal-server-request">
        <DialogHeader className="flex flex-row items-center justify-between">
          <div>
            <DialogTitle className="text-3xl font-bold text-primary mb-2" data-testid="text-modal-title">Crear Servidor</DialogTitle>
            <p className="text-muted-foreground" data-testid="text-modal-subtitle">Configura tu servidor personalizado de Minecraft</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-close-modal"
          >
            <X className="h-6 w-6" />
          </Button>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-server-request">
          {/* Personal Information */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-foreground mb-4" data-testid="text-section-personal">Información Personal</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-medium text-foreground">Nombre *</Label>
                <Input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Tu nombre completo"
                  className="w-full"
                  data-testid="input-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-foreground">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="tu@email.com"
                  className="w-full"
                  data-testid="input-email"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="discord" className="text-sm font-medium text-foreground">Discord (Opcional)</Label>
              <Input
                id="discord"
                type="text"
                value={formData.discord}
                onChange={(e) => handleInputChange('discord', e.target.value)}
                placeholder="Usuario#1234"
                className="w-full"
                data-testid="input-discord"
              />
            </div>
          </div>

          {/* Server Configuration */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-foreground mb-4" data-testid="text-section-server">Configuración del Servidor</h3>
            
            <div className="space-y-2">
              <Label htmlFor="serverName" className="text-sm font-medium text-foreground">Nombre del Servidor *</Label>
              <Input
                id="serverName"
                type="text"
                required
                value={formData.serverName}
                onChange={(e) => handleInputChange('serverName', e.target.value)}
                placeholder="Mi Servidor Épico"
                className="w-full"
                data-testid="input-server-name"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="version" className="text-sm font-medium text-foreground">Versión de Minecraft *</Label>
                <Select value={formData.version} onValueChange={(value) => handleInputChange('version', value)} required>
                  <SelectTrigger className="w-full" data-testid="select-version">
                    <SelectValue placeholder="Seleccionar versión" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1.21" data-testid="option-version-1.21">1.21 (Más reciente)</SelectItem>
                    <SelectItem value="1.20" data-testid="option-version-1.20">1.20</SelectItem>
                    <SelectItem value="1.19" data-testid="option-version-1.19">1.19</SelectItem>
                    <SelectItem value="1.18" data-testid="option-version-1.18">1.18</SelectItem>
                    <SelectItem value="1.17" data-testid="option-version-1.17">1.17</SelectItem>
                    <SelectItem value="1.16" data-testid="option-version-1.16">1.16</SelectItem>
                    <SelectItem value="1.15" data-testid="option-version-1.15">1.15</SelectItem>
                    <SelectItem value="1.14" data-testid="option-version-1.14">1.14</SelectItem>
                    <SelectItem value="1.13" data-testid="option-version-1.13">1.13</SelectItem>
                    <SelectItem value="1.12" data-testid="option-version-1.12">1.12</SelectItem>
                    <SelectItem value="1.11" data-testid="option-version-1.11">1.11</SelectItem>
                    <SelectItem value="1.10" data-testid="option-version-1.10">1.10</SelectItem>
                    <SelectItem value="1.9" data-testid="option-version-1.9">1.9</SelectItem>
                    <SelectItem value="1.8" data-testid="option-version-1.8">1.8</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-sm font-medium text-foreground">Modalidades de Juego * (Selecciona una o más)</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4" data-testid="gamemodes-grid">
                {gamemodeOptions.map((option) => (
                  <div key={option.value} className="relative">
                    <Card className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                      formData.gamemodes.includes(option.value) 
                        ? 'border-primary border-2 bg-primary/10' 
                        : 'border-border hover:border-primary/50'
                    }`} onClick={() => handleGamemodeToggle(option.value)} data-testid={`gamemode-card-${option.value}`}>
                      <CardContent className="p-0">
                        <div className="relative h-24 w-full overflow-hidden rounded-t-lg">
                          <img 
                            src={option.image} 
                            alt={option.label}
                            className="h-full w-full object-cover"
                            data-testid={`gamemode-image-${option.value}`}
                          />
                          <div className="absolute top-2 right-2">
                            <Checkbox 
                              checked={formData.gamemodes.includes(option.value)}
                              onChange={() => {}} // Handled by card click
                              className="bg-white"
                              data-testid={`gamemode-checkbox-${option.value}`}
                            />
                          </div>
                        </div>
                        <div className="p-3">
                          <h4 className="text-sm font-semibold text-center" data-testid={`gamemode-label-${option.value}`}>
                            {option.label}
                          </h4>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-medium text-foreground">Descripción Adicional</Label>
              <Textarea
                id="description"
                rows={4}
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe características especiales, plugins específicos, o cualquier detalle importante para tu servidor..."
                className="w-full resize-none"
                data-testid="textarea-description"
              />
            </div>
          </div>

          {/* Anti-bot Protection */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-foreground mb-4" data-testid="text-section-captcha">Verificación Anti-Bot</h3>
            <Card className="bg-muted" data-testid="card-captcha">
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div className="text-lg font-semibold" data-testid="text-captcha-question">{captcha.question}</div>
                  <Input
                    type="number"
                    required
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    placeholder="?"
                    className="w-24"
                    data-testid="input-captcha-answer"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={generateCaptcha}
                    className="text-muted-foreground hover:text-foreground"
                    data-testid="button-refresh-captcha"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-2" data-testid="text-captcha-help">Resuelve la operación matemática para continuar</p>
              </CardContent>
            </Card>
          </div>

          {/* Submit Button */}
          <div className="pt-6">
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-4 rounded-xl font-semibold text-lg transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={serverRequestMutation.isPending}
              data-testid="button-submit-request"
            >
              <Send className="mr-3 h-5 w-5" />
              {serverRequestMutation.isPending ? "Enviando..." : "Enviar Solicitud"}
            </Button>
            <p className="text-sm text-muted-foreground text-center mt-4" data-testid="text-submit-help">
              Te contactaremos en las próximas 24 horas con los detalles de tu servidor.
            </p>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
